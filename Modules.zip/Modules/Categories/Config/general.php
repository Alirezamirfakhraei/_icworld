<?php

return[
    /*
    |--------------------------------------------------------------------------
    | Categories version
    |--------------------------------------------------------------------------
    |
    | version of product's categories must be changed after that categories table
    | changed.
    |
    */

    'version' => '1.1.0',
];
